-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: crowdFunding
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `News`
--

DROP TABLE IF EXISTS `News`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `News` (
  `newsNum` int NOT NULL AUTO_INCREMENT COMMENT '새소식 번호',
  `charDivision` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'F: FAQ\\nP: 결제\\nC: 교환/펀딩금 반환/AS\\nA: 달성률\\nS: 발송\\nM: 매이킹 스토리\\nE: 이벤트\\nR: 리워드안내\\netc: 기타',
  `projectNum` int NOT NULL COMMENT '편의를 위해 종속관계를 반대로 체크함',
  `title` varchar(800) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '제목',
  `contents` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '글 내용',
  `regDate` timestamp NOT NULL COMMENT '작성일',
  `tmpNum` bigint DEFAULT NULL,
  PRIMARY KEY (`newsNum`),
  KEY `FKh6subafr37qj6o1enr9glq7di` (`projectNum`),
  CONSTRAINT `FKh6subafr37qj6o1enr9glq7di` FOREIGN KEY (`projectNum`) REFERENCES `FundingProject` (`num`),
  CONSTRAINT `NW_FP_projectNum_FK` FOREIGN KEY (`projectNum`) REFERENCES `FundingProject` (`num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='프로젝트 새 소식';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `News`
--

LOCK TABLES `News` WRITE;
/*!40000 ALTER TABLE `News` DISABLE KEYS */;
INSERT INTO `News` VALUES (1,'R',4,'new title test 1','contents test 1','2021-01-02 11:38:07',4),(2,'R',10,'new title test 2','contents test 2','2021-01-02 11:38:45',10),(3,'P',4,'new title test 2','contents test 2','2021-01-02 11:39:16',4),(4,'M',4,'new title test 3','contents test 3','2021-01-02 11:39:28',4);
/*!40000 ALTER TABLE `News` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-22 19:08:47
