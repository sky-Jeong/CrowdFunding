-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: crowdFunding
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `PurchaseInfo`
--

DROP TABLE IF EXISTS `PurchaseInfo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `PurchaseInfo` (
  `orderNum` int NOT NULL AUTO_INCREMENT COMMENT '주문정보 번호(기본키)',
  `memberNum` int NOT NULL COMMENT '멤버 번호',
  `buyer_name` varchar(200) NOT NULL COMMENT '수령인',
  `buyer_postcode` varchar(200) NOT NULL COMMENT '주문자 우편번호',
  `buyer_addr` varchar(400) NOT NULL COMMENT '주문자 주소 (상세주소 제외)',
  `buyer_tel` varchar(300) NOT NULL COMMENT '주문자 번호',
  `merchant_uid` varchar(200) NOT NULL COMMENT '주문 uid',
  `scheduled_at` timestamp NOT NULL COMMENT '결제 예정일',
  `paid_at` timestamp NULL DEFAULT NULL COMMENT '결제 승인 시각',
  `paid_method` varchar(100) NOT NULL COMMENT '결제 방법',
  `amount` int NOT NULL COMMENT '주문 금액 (배송비 제외)',
  `ordered_at` timestamp NOT NULL COMMENT '주문일시',
  `custom_data` varchar(500) DEFAULT NULL COMMENT '배송시 요청사항',
  `shippingFee` int NOT NULL DEFAULT '0',
  `totalAmount` int NOT NULL DEFAULT '0',
  `customer_uid` varchar(100) DEFAULT NULL,
  `payAmount` int NOT NULL DEFAULT '0',
  `status` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '결제 예약' COMMENT '- 결제 전: 결제 예약 / 펀딩 취소: 예약 취소 / 결제 후 : 결제 완료',
  `projectNum` int NOT NULL,
  `buyer_addr_detail` varchar(300) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT '상세주소',
  `total_addr` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`orderNum`),
  KEY `PI_memberNum_FK_idx` (`memberNum`),
  KEY `FK7ig08m1cyjfy2uruu6dbnucw6` (`projectNum`),
  CONSTRAINT `FK3huik71ahj5a6dt7yatt9g4ur` FOREIGN KEY (`memberNum`) REFERENCES `Member` (`memberNum`),
  CONSTRAINT `FK7ig08m1cyjfy2uruu6dbnucw6` FOREIGN KEY (`projectNum`) REFERENCES `FundingProject` (`num`),
  CONSTRAINT `PI_memberNum_FK` FOREIGN KEY (`memberNum`) REFERENCES `Member` (`memberNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PI_projectNUm_FK` FOREIGN KEY (`projectNum`) REFERENCES `FundingProject` (`num`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PurchaseInfo`
--

LOCK TABLES `PurchaseInfo` WRITE;
/*!40000 ALTER TABLE `PurchaseInfo` DISABLE KEYS */;
INSERT INTO `PurchaseInfo` VALUES (362,63,'하늘수정테스트','03665','서울 서대문구 증가로8길 29','010-4609-2222','merchant_1610672215422','2020-01-21 00:00:00',NULL,'card',87000,'2021-01-15 01:20:49','요청사항 테스트',2000,89000,'63_9020',0,'예약 취소',4,'202호','서울 서대문구 증가로8길 29 202호');
/*!40000 ALTER TABLE `PurchaseInfo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-22 19:08:46
