-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: crowdFunding
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Purchase`
--

DROP TABLE IF EXISTS `Purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Purchase` (
  `purchaseNum` int NOT NULL AUTO_INCREMENT COMMENT '주문번호(기본키)',
  `purchaseInfoNum` int NOT NULL COMMENT '주문정보 번호',
  `rewardNum` int NOT NULL COMMENT '리워드 번호',
  `orderQuantity` int NOT NULL COMMENT '주문 수량',
  `memberNum` int NOT NULL COMMENT '멤버 번호',
  `amount` int DEFAULT NULL,
  `purchaseOption` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`purchaseNum`),
  KEY `PC_rewardNum_FK_idx` (`rewardNum`),
  KEY `PC_orderNum_FK_idx` (`purchaseInfoNum`),
  KEY `PC_memberNum_FK_idx` (`memberNum`),
  CONSTRAINT `FKdks8r3td0x1ghiuj5lj595ms4` FOREIGN KEY (`memberNum`) REFERENCES `Member` (`memberNum`),
  CONSTRAINT `FKg4hm1u9vxj02ciq2svmsqkt2d` FOREIGN KEY (`purchaseInfoNum`) REFERENCES `PurchaseInfo` (`orderNum`),
  CONSTRAINT `FKm5uxk5yh0rrsmlewrgi68tffm` FOREIGN KEY (`rewardNum`) REFERENCES `FundingReward` (`productNum`),
  CONSTRAINT `PC_memberNum_FK` FOREIGN KEY (`memberNum`) REFERENCES `Member` (`memberNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PC_orderNum_FK` FOREIGN KEY (`purchaseInfoNum`) REFERENCES `PurchaseInfo` (`orderNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `PC_rewardNum_FK` FOREIGN KEY (`rewardNum`) REFERENCES `FundingReward` (`productNum`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=364 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Purchase`
--

LOCK TABLES `Purchase` WRITE;
/*!40000 ALTER TABLE `Purchase` DISABLE KEYS */;
INSERT INTO `Purchase` VALUES (363,362,6,3,63,0,NULL);
/*!40000 ALTER TABLE `Purchase` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-22 19:08:44
