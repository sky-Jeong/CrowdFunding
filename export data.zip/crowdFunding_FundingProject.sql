-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: crowdFunding
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `FundingProject`
--

DROP TABLE IF EXISTS `FundingProject`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `FundingProject` (
  `num` int NOT NULL AUTO_INCREMENT COMMENT '프로젝트 번호',
  `title` varchar(800) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '프로젝트 제목',
  `manager` varchar(400) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '프로젝트 관리자',
  `charDivision` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'F : funding / N : 프로젝트 새 뉴스',
  `categoryNum` int NOT NULL COMMENT '프로젝트 카테고리',
  `makerNum` int NOT NULL COMMENT '메이커(기업) 번호',
  `email` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '관리자 이메일',
  `businessDivision` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '개인/법인',
  `contents` mediumtext CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '오픈 후 수정 불가',
  `regDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'sysdate',
  `startDate` date NOT NULL COMMENT '달력 설정하듯 지정',
  `deadline` date NOT NULL COMMENT '등록일과 동일(2주 ~ 한 달)',
  `payDate` date NOT NULL COMMENT '종료일 다음 날',
  `sendDate` date NOT NULL COMMENT '리워드 발송일',
  `target` int NOT NULL DEFAULT '0' COMMENT '펀딩 목표 금액(최소 50)',
  `achievement` int NOT NULL COMMENT '펀딩 달성 금액[숫자로 노출]',
  `sign` int NOT NULL DEFAULT '0' COMMENT '기본 값: 0',
  `peopleLike` int NOT NULL DEFAULT '0' COMMENT '기본 값: 0',
  `supporter` int NOT NULL DEFAULT '0' COMMENT '기본 값: 0',
  `status` varchar(255) NOT NULL COMMENT 'Y : 진행중\nF : 종료\nC : 오픈 예정',
  `image` varchar(400) DEFAULT NULL,
  `countDown` int NOT NULL DEFAULT '0',
  `categoryNum2` varchar(45) DEFAULT NULL,
  `summary` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!',
  `projectGoal` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.',
  PRIMARY KEY (`num`),
  KEY `makerNum_idx` (`makerNum`),
  KEY `FKhq6evsg6pnujolbfkefr2kdok` (`categoryNum`),
  CONSTRAINT `FKhq6evsg6pnujolbfkefr2kdok` FOREIGN KEY (`categoryNum`) REFERENCES `Category` (`categoryNum`),
  CONSTRAINT `FKlv4fj2nqq6kvhacfpgpul79sw` FOREIGN KEY (`makerNum`) REFERENCES `MakerInfo` (`makerNum`),
  CONSTRAINT `FP_CA_categoryNum_FK` FOREIGN KEY (`categoryNum`) REFERENCES `Category` (`categoryNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FP_CF_makerNum_FK` FOREIGN KEY (`makerNum`) REFERENCES `MakerInfo` (`makerNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FundingProject_chk_1` CHECK ((`charDivision` in (_utf8mb3'F',_utf8mb3'N')))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='크라우드 펀딩 중 펀딩 프로젝트 리스트';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FundingProject`
--

LOCK TABLES `FundingProject` WRITE;
/*!40000 ALTER TABLE `FundingProject` DISABLE KEYS */;
INSERT INTO `FundingProject` VALUES (4,'[2만원대] 가성비 끝판왕 남여 공용 크로스백','manager 1','F',3,1,'email1@test.com','개인','<div>콘텐츠 작성 테스트 입니다.</div><p>작성한 콘텐츠에 html이 적용되는지 확인하기 위함입니다.</p><p>해당 내용이 적용돼야 할텐데요.</p>','2020-12-16 06:55:42','2020-12-16','2021-02-01','2020-01-21','2020-02-05',500000,250000,0,308,0,'Y','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',35,'3','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(5,'title2','manager 2','F',2,2,'email2@test.com','개인','contents 2','2020-12-16 06:55:42','2020-12-03','2020-12-23','2020-01-21','2020-02-05',1000000,2000000,0,1,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',29,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(6,'title3','manager 3','F',3,3,'email3@test.com','개인','contents 3','2020-12-16 06:55:42','2020-12-31','2021-01-20','2021-01-28','2021-02-02',1220000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',38,'3','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(7,'title0','manager0','F',2,1,'test0@test.com','개인','contents0','2020-12-16 07:39:18','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(8,'title1','manager1','F',2,1,'test1@test.com','개인','contents1','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,1,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(9,'title2','manager2','F',2,1,'test2@test.com','개인','contents2','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(10,'title3','manager3','F',2,1,'test3@test.com','개인','contents3','2020-12-16 07:39:19','2020-12-15','2021-02-01','2020-12-16','2020-12-16',1000000,2300000,0,5,0,'Y','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(11,'title4','manager4','F',2,1,'test4@test.com','개인','contents4','2020-12-16 07:39:19','2020-12-31','2021-01-20','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(12,'title5','manager5','F',2,1,'test5@test.com','개인','contents5','2020-12-16 07:39:19','2020-12-31','2021-01-20','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(13,'title6','manager6','F',2,1,'test6@test.com','개인','contents6','2020-12-16 07:39:19','2020-12-31','2021-01-20','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(14,'title7','manager7','F',2,1,'test7@test.com','개인','contents7','2020-12-16 07:39:19','2021-01-12','2021-02-01','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'2','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(15,'title8','manager8','F',4,1,'test8@test.com','개인','contents8','2020-12-16 07:39:19','2021-01-12','2021-02-01','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'4','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(16,'title9','manager9','F',4,1,'test9@test.com','개인','contents9','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,1,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'4','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(17,'title10','manager10','F',4,1,'test10@test.com','개인','contents10','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'4','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(18,'title11','manager11','F',4,1,'test11@test.com','개인','contents11','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'4','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(19,'title12','manager12','F',4,1,'test12@test.com','개인','contents12','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'4','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(20,'title13','manager13','F',4,1,'test13@test.com','개인','contents13','2020-12-16 07:39:19','2021-01-03','2021-01-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'4','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(21,'title14','manager14','F',4,1,'test14@test.com','개인','contents14','2020-12-16 07:39:19','2021-01-03','2021-01-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'4','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(22,'title15','manager15','F',3,1,'test15@test.com','개인','contents15','2020-12-16 07:39:19','2021-01-03','2021-01-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'3','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(23,'title16','manager16','F',3,1,'test16@test.com','개인','contents16','2020-12-16 07:39:19','2021-01-03','2021-01-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'C','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'3','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(24,'title17','manager17','F',3,1,'test17@test.com','개인','contents17','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'3','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(25,'title18','manager18','F',3,1,'test18@test.com','개인','contents18','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,150000,0,1,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'3','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.'),(26,'title19','manager19','F',3,1,'test19@test.com','개인','contents19','2020-12-16 07:39:19','2020-12-03','2020-12-23','2020-12-16','2020-12-16',1000000,0,0,0,0,'F','https://cdn1.wadiz.kr/images/20201123/1606126470501.jpg/wadiz/optimize',0,'3','프로젝트 스토리 요약 소개입니다! 여기에는 summary 컬럼에 작성한 내용이 들어갑니다. 이거는default!','프로젝트 스토리 중 진행 동기 및 목적입니다. 지금 작성된 내용은 default이며, 프로젝트 진행 동기 및 목적이 나타납니다.');
/*!40000 ALTER TABLE `FundingProject` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-22 19:08:45
