-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: crowdFunding
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Category`
--

DROP TABLE IF EXISTS `Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Category` (
  `categoryNum` int NOT NULL AUTO_INCREMENT COMMENT 'categoryNum',
  `charDivision` varchar(45) NOT NULL COMMENT 'F: funding / N: 프로젝트 새 소식',
  `categoryName` varchar(180) NOT NULL COMMENT 'category name',
  `categoryImage` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`categoryNum`),
  CONSTRAINT `Category_chk_1` CHECK ((`charDivision` in (_utf8mb4'F',_utf8mb4'N')))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='카테고리, 새 소식 등 카테고리 구분하는 것 리스트';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Category`
--

LOCK TABLES `Category` WRITE;
/*!40000 ALTER TABLE `Category` DISABLE KEYS */;
INSERT INTO `Category` VALUES (1,'F','전체보기','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_.jpg'),(2,'F','테크・가전','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_287.jpg'),(3,'F','패션・잡화','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_288.jpg'),(4,'F','뷰티','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_311.jpg'),(5,'F','푸드','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_289.jpg'),(6,'F','홈리빙','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_310.jpg'),(7,'F','디자인소품','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_290.jpg'),(8,'F','여행・레저','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_296.jpg'),(9,'F','스포츠・모빌리티','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_297.jpg'),(10,'F','반려동물','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_308.jpg'),(11,'F','모임','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_313.jpg'),(12,'F','공연・컬쳐','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_294.jpg'),(13,'F','소셜・캠페인','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_295.jpg'),(14,'F','교육・키즈','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_309.jpg'),(15,'F','게임・취미','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_292.jpg'),(16,'F','출판','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_293.jpg'),(17,'F','기부・후원','/assets/reward-category/reward_banner_thumb/reward_banner_thumb_312.jpg');
/*!40000 ALTER TABLE `Category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-22 19:08:44
