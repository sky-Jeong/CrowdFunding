-- MySQL dump 10.13  Distrib 8.0.22, for macos10.15 (x86_64)
--
-- Host: 127.0.0.1    Database: crowdFunding
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Community`
--

DROP TABLE IF EXISTS `Community`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Community` (
  `writeNum` int NOT NULL AUTO_INCREMENT COMMENT '작성 번호',
  `projectNum` int NOT NULL COMMENT '프로젝트 번호',
  `contents` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '작성 내용',
  `regDate` timestamp NOT NULL COMMENT '작성일',
  `writer` int NOT NULL COMMENT '작성자',
  `ref` int NOT NULL COMMENT '기본적으로 작성번호와 동일',
  `step` int NOT NULL COMMENT '들여쓰기',
  `category` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT 'C: 응원 / O: 의견 / R: 체험 리뷰 / RP: 답글',
  `tmpNum` int NOT NULL,
  `memberNum` int NOT NULL,
  PRIMARY KEY (`writeNum`),
  KEY `FKjdj5m1ekvcw3uqthl6kes3f5m` (`projectNum`),
  KEY `CM_MB_memberNum_FK_idx` (`memberNum`),
  CONSTRAINT `CM_FP_projectNum_FK` FOREIGN KEY (`projectNum`) REFERENCES `FundingProject` (`num`) ON DELETE CASCADE,
  CONSTRAINT `CM_MB_memberNum_FK` FOREIGN KEY (`memberNum`) REFERENCES `Member` (`memberNum`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK76thouft6cmh63v3e3sf5nlqr` FOREIGN KEY (`memberNum`) REFERENCES `Member` (`memberNum`),
  CONSTRAINT `FKjdj5m1ekvcw3uqthl6kes3f5m` FOREIGN KEY (`projectNum`) REFERENCES `FundingProject` (`num`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='댓글 설정은 원노트 댓글 설정 참고';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Community`
--

LOCK TABLES `Community` WRITE;
/*!40000 ALTER TABLE `Community` DISABLE KEYS */;
INSERT INTO `Community` VALUES (1,4,'코멘트 내용입니다.','2021-01-04 09:55:28',61,1,0,'C',4,61),(2,4,'코멘트 내용입니다. 2','2021-01-04 09:56:11',61,2,0,'C',4,61),(3,4,'답글 내용입니다.','2021-01-04 09:57:31',63,1,1,'RP',4,63),(65,4,'답글 남기기 테스트지롱 헤헤헤ㅔ헤헤헤헤헤헤ㅔ헤헿 뿌엥','2021-01-05 07:37:36',63,1,1,'RP',4,63),(66,4,'코멘트 2에다가 함 넣어보자구! 이번에 writeNum 값이 제대로 들어가길 ㅠㅠ','2021-01-05 07:42:24',63,2,1,'RP',4,63),(67,4,'코멘트 2에 다시 시도하는 답글 달기 테스트! 입력 성공하면 입력 성공 메시지 띄우고 다시 여기로 돌아오고, 아니면 입력 실패 메시지 띄우고 다시 여기로 백!','2021-01-05 07:47:50',63,2,1,'RP',4,63),(68,4,'응원 카테고리 선택해서 코멘트 입력 테스트 중!','2021-01-05 10:54:44',63,68,0,'C',4,63),(69,4,'코멘트의 리플 달기 테스트 중!!!','2021-01-05 10:58:02',61,68,1,'RP',4,61),(73,4,'한 글자 이하 작성할 경우 내용이 입력되지 않아용~!','2021-01-05 11:27:50',63,68,1,'RP',4,63),(85,10,'test','2021-01-05 15:28:19',63,85,0,'R',10,63);
/*!40000 ALTER TABLE `Community` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-22 19:08:46
